// Vercel Function 진입점: /api/* 요청은 vercel.json의 rewrites로 모두 여기로 와요.
import { handle } from '../lib/server.mjs';

export default { fetch: handle };
